import scutoid
import trimesh
import pyglet
import numpy as np

def main():
    points, faces = scutoid.scutoid1()
    mesh_points = []
    mesh_triangles = []
    letters = list(points.keys())
    mesh_points = list(points.values())

    for face in faces:
        print(face)
        first = face[0]
        for second, third in zip(face[1:], face [2:]):
            mesh_triangles.append([letters.index(first),
                                   letters.index(second),
                                   letters.index(third)])

    mesh = trimesh.Trimesh(vertices=mesh_points, faces=mesh_triangles)

    mesh.export('scutoid1.stl')


if __name__ == "__main__":
    main()
